package com.shpp.p2p.cs.bcimbal.assignment5;

import com.shpp.cs.a.console.TextProgram;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class Assignment5Part4 extends TextProgram {

    private static final String FILENAME = "my-csv.csv";


    public void run() {

        ArrayList<String> columnData;

        while (true) {
            int index = readInt("Enter column number:  ");
            columnData = extractColumn(FILENAME, index);
            if (columnData == null)
                println("Column with index " + index + " does not exist");
            else
                println(columnData);
        }
    }

    /*******************************************************************************************************************
     * Extract column
     *
     * @param filename String filename
     * @param columnIndex int column index will be extracted
     * @return ArrayList<String> representation of requested column
     */
    private ArrayList<String> extractColumn(String filename, int columnIndex) {

        ArrayList<String> row = readFromFile(filename);

        /* each object contains array of parsed children of each string of file*/
        Object[] temporary = new Object[row.size()];

        /* convert each strings of file to arrays of strings via ArrayList*/
        for (int k = 0; k < row.size(); k++) {
            /* add ArrayList to certain cell of object array*/
            temporary[k] = fieldsIn(row.get(k)).toArray();
        }

        if (columnIndex < 1 || ((Object[]) temporary[0]).length < columnIndex)
            return null;
        else {
            /* create ArrayList to return*/
            ArrayList<String> out = new ArrayList<>();
//            for (Object o : temporary) {
//                out.add(((Object[]) o)[columnIndex - 1].toString());
//            }

            for (int i = 0; i < temporary.length; i++) {
                String str = ((Object[]) temporary[i])[columnIndex - 1].toString();
                /* remove quotes if present */
                if(str.charAt(0) == '"') str = str.substring(1, str.length() - 1);
                out.add(str);
            }
            return out;
        }
    }

    /*******************************************************************************************************************
     * parse input string to arraylist
     *
     * @param line input string
     * @return ArrayList of children
     */
    private ArrayList<String> fieldsIn(String line) {

        ArrayList<String> tmp = new ArrayList<>();
        int startPosition = 0; //index of string next parse iteration will be started with
        boolean isQuoted = false; // current child is quoted

        /* pasrse current string and add it to ArrayList*/
        for (int currentPosition = startPosition; currentPosition < line.length(); currentPosition++) {
            char ch = line.charAt(currentPosition);
            if (ch == '"') isQuoted = !isQuoted;
            boolean last = false;
            /*check for <eos>*/
            if (currentPosition + 1 >= line.length()) {
                ch = ',';
                last = true;
            }

            /* child has been found*/
            if (ch == ',' && !isQuoted) {
                String a;
                if (last) a = line.substring(startPosition);
                else a =line.substring(startPosition, currentPosition);
                tmp.add(a);
                startPosition = currentPosition + 1;
            }
        }

        return tmp;
    }

    /*******************************************************************************************************************
     * Reads file rows as array list.
     *
     * @param filename String filename
     * @return ArrayList<String> representation of file rows
     */
    private ArrayList<String> readFromFile(String filename) {
        ArrayList<String> row = new ArrayList<>();
        try {
            FileReader fr = new FileReader("assets/" + filename);
            BufferedReader br = new BufferedReader(fr);
            while (true) {
                String str = br.readLine();
                if (str == null) break;
                row.add(str);
            }
        } catch (Exception e) {
            println(":-(");
        }
        return row;
    }
}
